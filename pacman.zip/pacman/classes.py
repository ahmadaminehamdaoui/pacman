import pygame 
main_font = 'lang/Emulogic.ttf'

class Vec2:
    def __init__(self, x, y):
        self.x = x
        self.y = y
class Button:
    def __init__(self, position, dimension, color, action, text=''):
        self.position = position
        self.dimension = dimension
        self.color = color
        self.text = text
        self.action = action
    
    def draw(self, surface, size, image=None): 
        if image != None:
            surface.blit(image, (self.position.x + (self.dimension.x/2 - image.get_width()/2), self.position.y + (self.dimension.y/2 - image.get_height()/2)))
        if self.text != '':
            font = pygame.font.Font(main_font, size)
            text = font.render(self.text, 1, (255,255,255))
            surface.blit(text, (self.position.x + (self.dimension.x/2 - text.get_width()/2) - 1, self.position.y + (self.dimension.y/2 - text.get_height()/2)))

    def is_hovered(self, pos):
        # pos is the mouse position or a Vector2(x,y)
        if pos.x > self.position.x and pos.x < self.position.x + self.dimension.x:
            if pos.y > self.position.y and pos.y < self.position.y + self.dimension.y:
                return True
        return False
class Label:
    def __init__(self, position, size, color, text='', centered=True):
        self.position = position
        self.size = size
        self.color = color
        self.text = text
        self.centered = centered
    
    def draw(self, surface): 
        if self.text != '':
            font = pygame.font.Font(main_font, self.size)
            text = font.render(self.text, 1, self.color)
            if self.centered:
                surface.blit(text, (self.position.x-text.get_width()/2, self.position.y-text.get_height()/2))
            else:
                surface.blit(text, (self.position.x, self.position.y))