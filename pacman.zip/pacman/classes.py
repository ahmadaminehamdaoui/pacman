import pygame 
main_font = 'lang/Emulogic.ttf'

class Vec2:
    def __init__(self, x, y):
        self.x = x
        self.y = y
class Button:
    def __init__(self, position, dimension, color, action, text=''):
        self.position = position
        self.dimension = dimension
        self.color = color
        self.text = text
        self.action = action
    
    def draw(self, surface, size, image=None, text=''): 
        if image != None:
            surface.blit(image, (self.position.x + (self.dimension.x/2 - image.get_width()/2), self.position.y + (self.dimension.y/2 - image.get_height()/2)))
        if text != '':
            font = pygame.font.Font(main_font, size)
            text = font.render(text, 1, (255,255,255))
            surface.blit(text, (self.position.x + (self.dimension.x/2 - text.get_width()/2) - 1, self.position.y + (self.dimension.y/2 - text.get_height()/2)))

    def is_hovered(self, pos):
        # pos is the mouse position or a Vector2(x,y)
        if pos.x > self.position.x and pos.x < self.position.x + self.dimension.x:
            if pos.y > self.position.y and pos.y < self.position.y + self.dimension.y:
                return True
        return False
class Label:
    def __init__(self, position, size, color, text='', centered=True):
        self.position = position
        self.size = size
        self.color = color
        self.text = text
        self.centered = centered
    
    def draw(self, surface, text=''): 
        if text != '':
            font = pygame.font.Font(main_font, self.size)
            text = font.render(text, 1, self.color)
            if self.centered:
                surface.blit(text, (self.position.x-text.get_width()/2, self.position.y-text.get_height()/2))
            else:
                surface.blit(text, (self.position.x, self.position.y))
                surface.blit(text, (self.position.x, self.position.y))
class DynamicLabel:
    def __init__(self, position, velocity, size, color, text='', centered=True, fade_speed=1):
        self.position = position
        self.size = size
        self.color = color
        self.text = text
        self.centered = centered
        self.velocity = velocity
        self.fade_speed = fade_speed
    
    def draw(self, surface, text=''): 
        if text != '':
            font = pygame.font.Font(main_font, self.size)
            text = font.render(text, 1, self.color)
            if self.centered:
                surface.blit(text, (self.position.x-text.get_width()/2, self.position.y-text.get_height()/2))
            else:
                surface.blit(text, (self.position.x, self.position.y))
                surface.blit(text, (self.position.x, self.position.y))
    
    def update(self):
        self.position = Vec2(self.position.x+self.velocity.x, self.position.y+self.velocity.y)
        self.color = (self.color[0]-10*self.fade_speed, self.color[1]-10*self.fade_speed, self.color[2]-10*self.fade_speed)
        if self.color[0]<0: self.color = (0, self.color[1], self.color[2])
        if self.color[1]<0: self.color = (self.color[0], 0, self.color[2])
        if self.color[2]<0: self.color = (self.color[0], self.color[1], 0)
class Entry:
    def __init__(self, position, dimensions, color=(200,200,200)):
        self.position = position
        self.dimensions = dimensions
        self.active = False
        self.color = color
        self.text = ''

class Shockwave:
    def __init__(self, position, radius, thickness=15, lifetime=100, speed=1, final_speed=2, color=(255,255,255)):
        self.position = position
        self.radius = radius
        self.thickness = thickness
        self.base_thickness = int(thickness)
        self.lifetime = lifetime
        self.color = color
        self.speed = speed
        self.final_speed = final_speed

    def update(self):
        if self.radius < self.lifetime/1.5:
            self.radius += int(8*self.speed)
        elif self.radius < self.lifetime/1.75:
            self.radius += int(5*self.speed)
        elif self.radius < self.lifetime:
            self.radius += int(2*self.final_speed*self.speed)

        self.thickness = self.base_thickness-self.radius*self.base_thickness/self.lifetime
class Player:
    def __init__(self, position, velocity):
        self.position = position
        self.spawnpoint = list(position)

        self.velocity = velocity
        self.try_velocity = velocity
        self.collision = None

        self.lives = 3
        self.invincibility = 0
        self.score = 0
        self.highscore = 0

        self.width = 30
        self.rotation = 0
        self.sprites = { '0': pygame.image.load('content/sprites/entities/pacman_closed.png'),   
                         '1': pygame.image.load('content/sprites/entities/pacman_open.png'),
                         '2': pygame.image.load('content/sprites/entities/pacman_wideopen.png'),
                         '3': pygame.image.load('content/sprites/entities/pacman_open.png'),
                         'alpha0': pygame.image.load('content/sprites/entities/alpha_pacman_closed.png'),   
                         'alpha1': pygame.image.load('content/sprites/entities/alpha_pacman_open.png'),
                         'alpha2': pygame.image.load('content/sprites/entities/alpha_pacman_wideopen.png'),
                         'alpha3': pygame.image.load('content/sprites/entities/alpha_pacman_open.png')
                       }
        self.sprite = self.sprites['0']       
class Ghost:
    def __init__(self, name, position):
        self.name = name
        self.position = position
        self.spawnpoint = list(position)
        self.target = [0,0]

        self.state = 'chase'
        self.value = 200
        
        self.direction = 'right'
        self.width = 30
        self.sprites = { 'right0': pygame.image.load('content/sprites/entities/'+self.name+'/ghost_right1.png'),
                         'right1': pygame.image.load('content/sprites/entities/'+self.name+'/ghost_right2.png'),
                         'left0': pygame.image.load('content/sprites/entities/'+self.name+'/ghost_left1.png'),
                         'left1': pygame.image.load('content/sprites/entities/'+self.name+'/ghost_left2.png'),
                         'up0': pygame.image.load('content/sprites/entities/'+self.name+'/ghost_up1.png'),
                         'up1': pygame.image.load('content/sprites/entities/'+self.name+'/ghost_up2.png'),
                         'down0': pygame.image.load('content/sprites/entities/'+self.name+'/ghost_down1.png'),
                         'down1': pygame.image.load('content/sprites/entities/'+self.name+'/ghost_down2.png'),
                         'frightened0': pygame.image.load('content/sprites/entities/frightened1.png'),
                         'frightened1': pygame.image.load('content/sprites/entities/frightened2.png'),
                         'deadright': pygame.image.load('content/sprites/entities/dead_right.png'),
                         'deadleft': pygame.image.load('content/sprites/entities/dead_left.png'),
                         'deadup': pygame.image.load('content/sprites/entities/dead_up.png'),
                         'deaddown': pygame.image.load('content/sprites/entities/dead_down.png'),
                       }
        self.sprite = self.sprites['down0']
class Pellet:
    def __init__(self, position, pellet_type):
        self.pellet_type = pellet_type
        self.position = position

        try: self.sprite = pygame.image.load('content/sprites/entities/pellets/'+self.pellet_type+'.png')
        except: self.sprite = pygame.image.load('content/sprites/tiles/ERROR.png')

        self.width = self.sprite.get_height()