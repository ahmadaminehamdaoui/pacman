from pygame import quit
from sys import exit

def stop():
    quit()
    exit()
