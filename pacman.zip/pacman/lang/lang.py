
values = {
    # menu scene
    'txt_subtitle': {'en':'- 2022 edition -', 'fr':'- édition 2022 -'},
    'txt_play': {'en':'play', 'fr':'jouer'},
    'txt_editor': {'en':'editor', 'fr':'éditeur'},
    'txt_settings': {'en':'settings', 'fr':'options'},
    'txt_quit': {'en':'quit', 'fr':'quitter'},

    # settings scene
    'txt_volume': {'en':'volume', 'fr':'volume'},
    'txt_fps': {'en':'fps', 'fr':'ips'},
    'txt_language': {'en':'language', 'fr':'langue'},
    'txt_dev': {'en':'dev. mode', 'fr':'mode dév.'},
    'txt_on': {'en':'on', 'fr':'activé'},
    'txt_off': {'en':'off', 'fr':'désactivé'},

    # editor
    'txt_newmap': {'en':'new', 'fr':'nouveau'},
    'txt_select': {'en':'select a map', 'fr':'sélectionnez une carte'},

    'txt_saved': {'en':'saved!', 'fr':'sauvegardé!'},
    'txt_notsaved': {'en':'there is no spawnpoint for pacman !', 'fr':'il n\'y a pas de point d\'apparition pour pacman!'},

    'txt_save': {'en':'save', 'fr':'sauvegarder'},
    'txt_eraser': {'en':'erase', 'fr':'effacer'},
    'txt_tile': {'en':'wall', 'fr':'mur'},
    'txt_power_pellet': {'en':'power', 'fr':'pouvoir'},

    # in game
    'txt_victory': {'en':'victory!', 'fr':'victoire!'},
    'txt_defeat': {'en':'defeat!', 'fr':'défaite!'},
    'txt_retry': {'en':'replay', 'fr':'rejouer'},

    # other
    'txt_confirm': {'en':'confirm', 'fr':'confirmer'}
}

def translate(lang, txt):
    global values
    return values[txt]['en'] if lang == 'en' else values[txt]['fr'] 