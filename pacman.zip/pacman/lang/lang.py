
values = {
    # menu scene
    'txt_subtitle': {'en':'- 2022 edition -', 'fr':'- édition 2022 -'},
    'txt_play': {'en':'play', 'fr':'jouer'},
    'txt_editor': {'en':'editor', 'fr':'éditeur'},
    'txt_settings': {'en':'settings', 'fr':'options'},
    'txt_quit': {'en':'quit', 'fr':'quitter'},

    # settings scene
    'txt_volume': {'en':'volume', 'fr':'volume'},
    'txt_fps': {'en':'fps', 'fr':'ips'},
    'txt_language': {'en':'language', 'fr':'langue'},
    'txt_dev': {'en':'dev. mode', 'fr':'mode dév.'},
    'txt_on': {'en':'on', 'fr':'activé'},
    'txt_off': {'en':'off', 'fr':'désactivé'},
}

def translate(lang, txt):
    global values
    return values[txt]['en'] if lang == 'en' else values[txt]['fr'] 