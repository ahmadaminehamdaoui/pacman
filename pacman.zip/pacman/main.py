import pygame, sys, ctypes

from pygame.constants import K_F1, K_F2, K_F3, K_F4, K_F5, K_F6, K_MINUS, K_PLUS
from classes import *
from functions import *
from lang.lang import *

# get screen resolution
user32 = ctypes.windll.user32
width, height = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)

# setup
pygame.init()
pygame.display.init()
screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
clock = pygame.time.Clock()
pygame.display.set_caption('Pacman 2022')

# images
BUTTON_WIDE = pygame.image.load('content/sprites/UI/button_wide.png')
BUTTON_WIDE_HOVERED = pygame.transform.scale(BUTTON_WIDE,(int(BUTTON_WIDE.get_width()*1.2), int(BUTTON_WIDE.get_height()*1.2)))
BUTTON_SMALL = pygame.image.load('content/sprites/UI/button_small.png')
BUTTON_SMALL_HOVERED = pygame.transform.scale(BUTTON_SMALL,(int(BUTTON_SMALL.get_width()*1.2), int(BUTTON_SMALL.get_height()*1.2)))

# functions & variables
clicking = False
scene = 'menu'
objects = []
tilesheet = []
options = {
    "volume": 60,
    "fps": 60,
    "lang": 'fr',
    "dev": False
}

def set_scene(value):
    global scene, objects
    objects = []
    scene = value

def set_option(option, value):
    global options

    options[option] = value
    if option == "volume":
        if options[option] < 0: options[option]=0
        elif options[option] > 100: options[option]=100
    elif option == "fps":
        if options[option] < 10: options[option]=10
        elif options[option] > 120: options[option]=120

# main game logic
while True:
    # loop init
    screen.fill((0,0,0))
    mouse_x, mouse_y = pygame.mouse.get_pos()
    
    # reset
    buttons = []
    labels = []

    # scenes
    if scene == 'menu':
        buttons.append(Button(Vec2(width/2-125,height*0.55),Vec2(250,60),(255,255,255),lambda:set_scene('play'),text=translate(options['lang'], 'txt_play')))
        buttons.append(Button(Vec2(width/2-125,height*0.60),Vec2(250,60),(255,255,255),lambda:set_scene('editor'),text=translate(options['lang'], 'txt_editor')))
        buttons.append(Button(Vec2(width/2-125,height*0.65),Vec2(250,60),(255,255,255),lambda:set_scene('settings'),text=translate(options['lang'], 'txt_settings')))
        buttons.append(Button(Vec2(width/2-125,height*0.70),Vec2(250,60),(255,255,255),lambda:stop(),text=translate(options['lang'], 'txt_quit')))
        
        labels.append(Label(Vec2(width/2,height*0.4), 80, (255,216,0), 'PACMAN'))
        labels.append(Label(Vec2(width/2,height*0.46), 18, (255,0,0), translate(options['lang'], 'txt_subtitle')))
    if scene == 'settings':
        buttons.append(Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'))
        
        labels.append(Label(Vec2(width/2,height*0.35), 20, (255,255,255), translate(options['lang'], 'txt_volume')))
        labels.append(Label(Vec2(width/2,height*0.35+30), 15, (255,255,255), str(options['volume'])))
        buttons.append(Button(Vec2(width/2-150,height*0.33),Vec2(60,60),(255,255,255),lambda:set_option('volume', options['volume']-5),text='-'))
        buttons.append(Button(Vec2(width/2+100,height*0.33),Vec2(60,60),(255,255,255),lambda:set_option('volume', options['volume']+5),text='+'))

        labels.append(Label(Vec2(width/2,height*0.45), 20, (255,255,255), translate(options['lang'], 'txt_fps')))
        labels.append(Label(Vec2(width/2,height*0.45+30), 15, (255,255,255), str(options['fps'])))
        buttons.append(Button(Vec2(width/2-150,height*0.43),Vec2(60,60),(255,255,255),lambda:set_option('fps', options['fps']-10),text='-'))
        buttons.append(Button(Vec2(width/2+100,height*0.43),Vec2(60,60),(255,255,255),lambda:set_option('fps', options['fps']+10),text='+'))

        labels.append(Label(Vec2(width/2,height*0.55), 20, (255,255,255), translate(options['lang'], 'txt_language')))
        labels.append(Label(Vec2(width/2,height*0.55+30), 15, (255,255,255), str('english' if options['lang']=='en' else 'francais')))
        buttons.append(Button(Vec2(width/2-150,height*0.53),Vec2(60,60),(255,255,255),lambda:set_option('lang', 'fr'),text='f'))
        buttons.append(Button(Vec2(width/2+100,height*0.53),Vec2(60,60),(255,255,255),lambda:set_option('lang', 'en'),text='e'))

        labels.append(Label(Vec2(width/2,height*0.65), 20, (255,255,255), translate(options['lang'], 'txt_dev')))
        labels.append(Label(Vec2(width/2,height*0.65+30), 15, (255,255,255), (translate(options['lang'], 'txt_on') if options['dev']==True else translate(options['lang'], 'txt_off'))))
        buttons.append(Button(Vec2(width/2-150,height*0.63),Vec2(60,60),(255,255,255),lambda:set_option('dev', False),text='x'))
        buttons.append(Button(Vec2(width/2+100,height*0.63),Vec2(60,60),(255,255,255),lambda:set_option('dev', True),text='o'))
    if scene == 'editor':
        buttons.append(Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'))
    if scene == 'play':
        buttons.append(Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'))        
        
        labels.append(Label(Vec2(width/2,height*0.4), 20, (255,255,255), '- SELECT A GAME MODE -'))
        buttons.append(Button(Vec2(width/2-125,height*0.45),Vec2(250,60),(255,255,255),lambda:set_scene('play'),text='CLASSIC'))
        buttons.append(Button(Vec2(width/2-125,height*0.5),Vec2(250,60),(255,255,255),lambda:set_scene('play'),text='DUEL'))
    
    # events handler
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            stop()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            clicking = True
            for button in buttons:
                if button.is_hovered(Vec2(mouse_x, mouse_y)):
                    button.action()
        elif event.type == pygame.MOUSEBUTTONUP:
            clicking = False
        
        elif event.type == pygame.KEYDOWN:
            if event.key == K_F1:
                set_option('volume', options['volume']-5)
            elif event.key == K_F2:
                set_option('volume', options['volume']+5)
            if event.key == K_F3:
                set_option('fps', options['fps']-10)
            elif event.key == K_F4:
                set_option('fps', options['fps']+10)
            elif event.key == K_F5:
                options['lang'] = 'en' if options['lang']=='fr' else 'fr'
            elif event.key == K_F6:
                options['dev'] = False if options['dev'] else True
            
            

    
    # dev mode
    if options['dev']:
        labels.append(Label(Vec2(10, height-20), 11, (255,255,255), 'fps '+str(round(clock.get_fps(),4)), centered = False))
        labels.append(Label(Vec2(10, height-32), 11, (255,255,255), 'res '+str(width)+'x'+str(height), centered = False))
        labels.append(Label(Vec2(10, height-44), 11, (255,255,255), 'sce '+scene, centered = False))
        if clicking:
            labels.append(Label(Vec2(10, height-56), 11, (255,255,255), 'clk True', centered = False))
        else:
            labels.append(Label(Vec2(10, height-56), 11, (255,255,255), 'clk False', centered = False))
        for button in buttons:
            pygame.draw.rect(screen, (75,0,0), pygame.Rect(button.position.x, button.position.y, button.dimension.x, button.dimension.y), 1)
        for label in labels:
            pygame.draw.rect(screen, (0,0,75), pygame.Rect(0, label.position.y, width, 1))

    # ui drawing
    for button in buttons:
        if len(button.text) > 2:
            if button.is_hovered(Vec2(mouse_x, mouse_y)):
                button.draw(screen, size=20, image=BUTTON_WIDE_HOVERED)
            else:
                button.draw(screen, size=20, image=BUTTON_WIDE)
        else:
            if button.is_hovered(Vec2(mouse_x, mouse_y)):
                button.draw(screen, size=20, image=BUTTON_SMALL_HOVERED)
            else:
                button.draw(screen, size=20, image=BUTTON_SMALL)
    for label in labels:
            label.draw(screen)

    # update
    pygame.display.update()
    clock.tick(options['fps'])
