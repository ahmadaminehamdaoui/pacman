'''
PAR HAMDAOUI AHMAD-AMINE, 1G7
'''

import pygame, sys, ctypes
from pygame.constants import K_F1, K_F2, K_F3, K_F4, K_F5, K_F6, K_MINUS, K_PLUS
from classes import *
from lang.lang import *

# get screen resolution
user32 = ctypes.windll.user32
width, height = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)

# setup
pygame.init()
pygame.display.init()
screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
clock = pygame.time.Clock()
pygame.display.set_caption('Pacman 2022')

# images
BUTTON_WIDE = pygame.image.load('content/sprites/UI/button_wide.png')
BUTTON_WIDE_HOVERED = pygame.transform.scale(BUTTON_WIDE,(int(BUTTON_WIDE.get_width()*1.2), int(BUTTON_WIDE.get_height()*1.2)))
BUTTON_SMALL = pygame.image.load('content/sprites/UI/button_small.png')
BUTTON_SMALL_HOVERED = pygame.transform.scale(BUTTON_SMALL,(int(BUTTON_SMALL.get_width()*1.2), int(BUTTON_SMALL.get_height()*1.2)))
PACMAN = pygame.image.load('content/sprites/entities/pacman.png')

# variables
clicking = False
objects = []
options = {
    "volume": 60,
    "fps": 60,
    "lang": 'fr',
    "dev": False
}

map = [
                 [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
                 [1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
                 [1,0,1,1,1,1,1,0,1,1,1,1,1,0,1],
                 [1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
                 [1,0,1,1,1,1,1,0,1,1,1,1,1,0,1],
                 [1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
                 [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
       ]
tiles = []
for y in range(len(map)):
    for x in range(len(map[0])):
        map[y][x]==1
        tiles.append([x*32,y*32])

# scenes
scenes = {
    'menu' : {'buttons' :
              [
                Button(Vec2(width/2-125,height*0.55),Vec2(250,60),(255,255,255),lambda:set_scene('play'),text=translate(options['lang'], 'txt_play')),
                Button(Vec2(width/2-125,height*0.60),Vec2(250,60),(255,255,255),lambda:set_scene('editor'),text=translate(options['lang'], 'txt_editor')),
                Button(Vec2(width/2-125,height*0.65),Vec2(250,60),(255,255,255),lambda:set_scene('settings'),text=translate(options['lang'], 'txt_settings')),
                Button(Vec2(width/2-125,height*0.70),Vec2(250,60),(255,255,255),lambda:stop(),text=translate(options['lang'], 'txt_quit'))
              ],

              'labels' :
              [
                Label(Vec2(width/2,height*0.4), 80, (255,216,0), 'PACMAN'),
                Label(Vec2(width/2,height*0.46), 18, (255,0,0), translate(options['lang'], 'txt_subtitle'))
              ]
             },

    'settings' : {'buttons' :
                   [
                    Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'),
                    Button(Vec2(width/2-150,height*0.33),Vec2(60,60),(255,255,255),lambda:set_option('volume', options['volume']-5),text='-'),
                    Button(Vec2(width/2+100,height*0.33),Vec2(60,60),(255,255,255),lambda:set_option('volume', options['volume']+5),text='+'),
                    Button(Vec2(width/2-150,height*0.43),Vec2(60,60),(255,255,255),lambda:set_option('fps', options['fps']-10),text='-'),
                    Button(Vec2(width/2+100,height*0.43),Vec2(60,60),(255,255,255),lambda:set_option('fps', options['fps']+10),text='+'),
                    Button(Vec2(width/2-150,height*0.53),Vec2(60,60),(255,255,255),lambda:set_option('lang', 'fr'),text='f'),
                    Button(Vec2(width/2+100,height*0.53),Vec2(60,60),(255,255,255),lambda:set_option('lang', 'en'),text='e'),
                    Button(Vec2(width/2-150,height*0.63),Vec2(60,60),(255,255,255),lambda:set_option('dev', False),text='x'),
                    Button(Vec2(width/2+100,height*0.63),Vec2(60,60),(255,255,255),lambda:set_option('dev', True),text='o')
                   ],
              'labels' :
                  [
                    Label(Vec2(width/2,height*0.35), 20, (255,255,255), translate(options['lang'], 'txt_volume')),
                    Label(Vec2(width/2,height*0.35+30), 15, (255,255,255), str(options['volume'])),
                    Label(Vec2(width/2,height*0.45), 20, (255,255,255), translate(options['lang'], 'txt_fps')),
                    Label(Vec2(width/2,height*0.45+30), 15, (255,255,255), str(options['fps'])),
                    Label(Vec2(width/2,height*0.55), 20, (255,255,255), translate(options['lang'], 'txt_language')),
                    Label(Vec2(width/2,height*0.55+30), 15, (255,255,255), str('english' if options['lang']=='en' else 'francais')),
                    Label(Vec2(width/2,height*0.65), 20, (255,255,255), translate(options['lang'], 'txt_dev')),
                    Label(Vec2(width/2,height*0.65+30), 15, (255,255,255), (translate(options['lang'], 'txt_on') if options['dev']==True else translate(options['lang'], 'txt_off'))),
                  ]
             },

    'editor' : {'buttons' :
              [
                Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<')
              ],

              'labels' : []
             },

    'play' : {'buttons' :
              [
                Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'),
                Button(Vec2(width/2-125,height*0.45),Vec2(250,60),(255,255,255),lambda:set_scene('ingame_classic'),text='CLASSIC'),
                Button(Vec2(width/2-125,height*0.5),Vec2(250,60),(255,255,255),lambda:set_scene('play'),text='DUEL')
              ],

              'labels' : [Label(Vec2(width/2,height*0.4), 20, (255,255,255), '- SELECT A GAME MODE -')]
             },
    }
scene = scenes['menu']

# fonctions
def stop():
    quit()
    exit()

def set_scene(value):
    global scenes, scene
    scene = scenes[value]

def set_option(option, value):
    global options

    options[option] = value
    if option == "volume":
        if options[option] < 0: options[option]=0
        elif options[option] > 100: options[option]=100
    elif option == "fps":
        if options[option] < 10: options[option]=10
        elif options[option] > 120: options[option]=120

def isColliding(rect1, rect2, rect2size):
    rect2size -= 1
    if(rect1.position[0] >= rect2[0] and rect1.position[0] <= rect2[0]+rect2size and rect1.position[1] >= rect2[1] and rect1.position[1] <= rect2[1]+rect2size) or (rect1.position[0]+rect1.sprite_size >= rect2[0] and rect1.position[0]+rect1.sprite_size <= rect2[0]+rect2size and rect1.position[1] >= rect2[1] and rect1.position[1] <= rect2[1]+rect2size) or (rect1.position[0] >= rect2[0] and rect1.position[0] <= rect2[0]+rect2size and rect1.position[1]+rect1.sprite_size >= rect2[1] and rect1.position[1]+rect1.sprite_size <= rect2[1]+rect2size) or (rect1.position[0]+rect1.sprite_size >= rect2[0] and rect1.position[0]+rect1.sprite_size <= rect2[0]+rect2size and rect1.position[1]+rect1.sprite_size >= rect2[1] and rect1.position[1]+rect1.sprite_size <= rect2[1]+rect2size):
        return True
    return False

# main game logic
while True:
    # loop init
    screen.fill((0,0,0))
    mouse_x, mouse_y = pygame.mouse.get_pos()

    if 'ingame' not in scene:
        player = None

    elif scene == 'ingame_classic':
        # buttons & labels
        buttons.append(Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'))

        # ingame logic
        if player == None:
            player = Player((33,33), 'right', PACMAN)
        dimensions = (15, 7)
        origin = ((width/2)-(dimensions[0]*32/2), (height/2)-(dimensions[1]*32/2))

        if player.velocity == 'up':
            player.position = (player.position[0], player.position[1]-4)
        elif player.velocity == 'down':
            player.position = (player.position[0], player.position[1]+4)
        elif player.velocity == 'right':
            player.position = (player.position[0]+4, player.position[1])
        elif player.velocity == 'left':
            player.position = (player.position[0]-4, player.position[1])

        for tile in tiles:
            if isColliding(player, tile, 32):
                player.isColliding = tile
        while player.isColliding != None:
            if player.velocity == 'up':
                player.position = (player.position[0], player.position[1]+1)
            elif player.velocity == 'down':
                player.position = (player.position[0], player.position[1]-1)
            elif player.velocity == 'right':
                player.position = (player.position[0]-1, player.position[1])
            elif player.velocity == 'left':
                    player.position = (player.position[0]+1, player.position[1])
            if not isColliding(player, player.isColliding, 32):
                player.isColliding = None

        # map
        for y in range(len(map)):
            for x in range(len(map[0])):
                if map[y][x]==1:
                    pygame.draw.rect(screen, (0,0,255), pygame.Rect(origin[0]+x*32, origin[1]+y*32, 32, 32))

        # dessin
        if options['dev']:
            pygame.draw.rect(screen, (255,0,0), pygame.Rect(origin[0]+player.position[0], origin[1]+player.position[1], player.sprite_size, player.sprite_size))
        final_sprite = pygame.transform.rotate(player.sprite, player.rotation)
        screen.blit(final_sprite, (origin[0]+player.position[0], origin[1]+player.position[1]))

    # events handler
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            stop()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            clicking = True
            for button in buttons:
                if button.is_hovered(Vec2(mouse_x, mouse_y)):
                    button.action()
        elif event.type == pygame.MOUSEBUTTONUP:
            clicking = False

        elif event.type == pygame.KEYDOWN:
            if event.key == K_F1:
                set_option('volume', options['volume']-5)
            elif event.key == K_F2:
                set_option('volume', options['volume']+5)
            if event.key == K_F3:
                set_option('fps', options['fps']-10)
            elif event.key == K_F4:
                set_option('fps', options['fps']+10)
            elif event.key == K_F5:
                options['lang'] = 'en' if options['lang']=='fr' else 'fr'
            elif event.key == K_F6:
                options['dev'] = False if options['dev'] else True

            if 'ingame' in scene:
                if event.key == pygame.K_UP:
                    player.velocity = 'up'
                    player.rotation = 90
                elif event.key == pygame.K_DOWN:
                    player.velocity = 'down'
                    player.rotation = 270
                elif event.key == pygame.K_RIGHT:
                    player.velocity = 'right'
                    player.rotation = 0
                elif event.key == pygame.K_LEFT:
                    player.velocity = 'left'
                    player.rotation = 180

    # dev mode
    dev = [Label(Vec2(10, height-20), 11, (255,255,255), 'fps '+str(round(clock.get_fps(),4)), centered = False),
           Label(Vec2(10, height-32), 11, (255,255,255), 'res '+str(width)+'x'+str(height), centered = False),
           Label(Vec2(10, height-44), 11, (255,255,255), 'sce '+scene, centered = False)]
    if clicking:
        dev.append(Label(Vec2(10, height-56), 11, (255,255,255), 'clk True', centered = False))
    else:
        dev.append(Label(Vec2(10, height-56), 11, (255,255,255), 'clk False', centered = False))

    # ui drawing
    for button in scene['buttons']:
        if len(button.text) > 2:
            if button.is_hovered(Vec2(mouse_x, mouse_y)):
                button.draw(screen, size=20, image=BUTTON_WIDE_HOVERED)
            else:
                button.draw(screen, size=20, image=BUTTON_WIDE)
        else:
            if button.is_hovered(Vec2(mouse_x, mouse_y)):
                button.draw(screen, size=20, image=BUTTON_SMALL_HOVERED)
            else:
                button.draw(screen, size=20, image=BUTTON_SMALL)
    for label in scene['labels']:
            label.draw(screen)
    if options['dev']:
        for label in dev:
            label.draw(screen)
        for button in scene['buttons']:
            pygame.draw.rect(screen, (75,0,0), pygame.Rect(button.position.x, button.position.y, button.dimension.x, button.dimension.y), 1)
        for label in scene['labels']:
            pygame.draw.rect(screen, (0,0,75), pygame.Rect(0, label.position.y, width, 1))

    # update
    pygame.display.update()
    clock.tick(options['fps'])

'''
# main game logic
while True:
    # loop init
    screen.fill((0,0,0))
    mouse_x, mouse_y = pygame.mouse.get_pos()

    # reset
    buttons = []
    labels = []
    if 'ingame' not in scene:
        player = None

    # scenes
    if scene == 'menu':
        buttons.append(Button(Vec2(width/2-125,height*0.55),Vec2(250,60),(255,255,255),lambda:set_scene('play'),text=translate(options['lang'], 'txt_play')))
        buttons.append(Button(Vec2(width/2-125,height*0.60),Vec2(250,60),(255,255,255),lambda:set_scene('editor'),text=translate(options['lang'], 'txt_editor')))
        buttons.append(Button(Vec2(width/2-125,height*0.65),Vec2(250,60),(255,255,255),lambda:set_scene('settings'),text=translate(options['lang'], 'txt_settings')))
        buttons.append(Button(Vec2(width/2-125,height*0.70),Vec2(250,60),(255,255,255),lambda:stop(),text=translate(options['lang'], 'txt_quit')))

        labels.append(Label(Vec2(width/2,height*0.4), 80, (255,216,0), 'PACMAN'))
        labels.append(Label(Vec2(width/2,height*0.46), 18, (255,0,0), translate(options['lang'], 'txt_subtitle')))
    elif scene == 'settings':
        buttons.append(Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'))

        labels.append(Label(Vec2(width/2,height*0.35), 20, (255,255,255), translate(options['lang'], 'txt_volume')))
        labels.append(Label(Vec2(width/2,height*0.35+30), 15, (255,255,255), str(options['volume'])))
        buttons.append(Button(Vec2(width/2-150,height*0.33),Vec2(60,60),(255,255,255),lambda:set_option('volume', options['volume']-5),text='-'))
        buttons.append(Button(Vec2(width/2+100,height*0.33),Vec2(60,60),(255,255,255),lambda:set_option('volume', options['volume']+5),text='+'))

        labels.append(Label(Vec2(width/2,height*0.45), 20, (255,255,255), translate(options['lang'], 'txt_fps')))
        labels.append(Label(Vec2(width/2,height*0.45+30), 15, (255,255,255), str(options['fps'])))
        buttons.append(Button(Vec2(width/2-150,height*0.43),Vec2(60,60),(255,255,255),lambda:set_option('fps', options['fps']-10),text='-'))
        buttons.append(Button(Vec2(width/2+100,height*0.43),Vec2(60,60),(255,255,255),lambda:set_option('fps', options['fps']+10),text='+'))

        labels.append(Label(Vec2(width/2,height*0.55), 20, (255,255,255), translate(options['lang'], 'txt_language')))
        labels.append(Label(Vec2(width/2,height*0.55+30), 15, (255,255,255), str('english' if options['lang']=='en' else 'francais')))
        buttons.append(Button(Vec2(width/2-150,height*0.53),Vec2(60,60),(255,255,255),lambda:set_option('lang', 'fr'),text='f'))
        buttons.append(Button(Vec2(width/2+100,height*0.53),Vec2(60,60),(255,255,255),lambda:set_option('lang', 'en'),text='e'))

        labels.append(Label(Vec2(width/2,height*0.65), 20, (255,255,255), translate(options['lang'], 'txt_dev')))
        labels.append(Label(Vec2(width/2,height*0.65+30), 15, (255,255,255), (translate(options['lang'], 'txt_on') if options['dev']==True else translate(options['lang'], 'txt_off'))))
        buttons.append(Button(Vec2(width/2-150,height*0.63),Vec2(60,60),(255,255,255),lambda:set_option('dev', False),text='x'))
        buttons.append(Button(Vec2(width/2+100,height*0.63),Vec2(60,60),(255,255,255),lambda:set_option('dev', True),text='o'))
    elif scene == 'editor':
        buttons.append(Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'))
    elif scene == 'play':
        buttons.append(Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'))

        labels.append(Label(Vec2(width/2,height*0.4), 20, (255,255,255), '- SELECT A GAME MODE -'))
        buttons.append(Button(Vec2(width/2-125,height*0.45),Vec2(250,60),(255,255,255),lambda:set_scene('ingame_classic'),text='CLASSIC'))
        buttons.append(Button(Vec2(width/2-125,height*0.5),Vec2(250,60),(255,255,255),lambda:set_scene('play'),text='DUEL'))

    elif scene == 'ingame_classic':
        # buttons & labels
        buttons.append(Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'))

        # ingame logic
        if player == None:
            player = Player((33,33), 'right', PACMAN)
        dimensions = (15, 7)
        origin = ((width/2)-(dimensions[0]*32/2), (height/2)-(dimensions[1]*32/2))

        if player.velocity == 'up':
            player.position = (player.position[0], player.position[1]-4)
        elif player.velocity == 'down':
            player.position = (player.position[0], player.position[1]+4)
        elif player.velocity == 'right':
            player.position = (player.position[0]+4, player.position[1])
        elif player.velocity == 'left':
            player.position = (player.position[0]-4, player.position[1])

        for tile in tiles:
            if isColliding(player, tile, 32):
                player.isColliding = tile
        while player.isColliding != None:
            if player.velocity == 'up':
                player.position = (player.position[0], player.position[1]+1)
            elif player.velocity == 'down':
                player.position = (player.position[0], player.position[1]-1)
            elif player.velocity == 'right':
                player.position = (player.position[0]-1, player.position[1])
            elif player.velocity == 'left':
                    player.position = (player.position[0]+1, player.position[1])
            if not isColliding(player, player.isColliding, 32):
                player.isColliding = None

        # map
        for y in range(len(map)):
            for x in range(len(map[0])):
                if map[y][x]==1:
                    pygame.draw.rect(screen, (0,0,255), pygame.Rect(origin[0]+x*32, origin[1]+y*32, 32, 32))

        # dessin
        if options['dev']:
            pygame.draw.rect(screen, (255,0,0), pygame.Rect(origin[0]+player.position[0], origin[1]+player.position[1], player.sprite_size, player.sprite_size))
        final_sprite = pygame.transform.rotate(player.sprite, player.rotation)
        screen.blit(final_sprite, (origin[0]+player.position[0], origin[1]+player.position[1]))

    # events handler
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            stop()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            clicking = True
            for button in buttons:
                if button.is_hovered(Vec2(mouse_x, mouse_y)):
                    button.action()
        elif event.type == pygame.MOUSEBUTTONUP:
            clicking = False

        elif event.type == pygame.KEYDOWN:
            if event.key == K_F1:
                set_option('volume', options['volume']-5)
            elif event.key == K_F2:
                set_option('volume', options['volume']+5)
            if event.key == K_F3:
                set_option('fps', options['fps']-10)
            elif event.key == K_F4:
                set_option('fps', options['fps']+10)
            elif event.key == K_F5:
                options['lang'] = 'en' if options['lang']=='fr' else 'fr'
            elif event.key == K_F6:
                options['dev'] = False if options['dev'] else True

            if 'ingame' in scene:
                if event.key == pygame.K_UP:
                    player.velocity = 'up'
                    player.rotation = 90
                elif event.key == pygame.K_DOWN:
                    player.velocity = 'down'
                    player.rotation = 270
                elif event.key == pygame.K_RIGHT:
                    player.velocity = 'right'
                    player.rotation = 0
                elif event.key == pygame.K_LEFT:
                    player.velocity = 'left'
                    player.rotation = 180

    # dev mode
    if options['dev']:
        labels.append(Label(Vec2(10, height-20), 11, (255,255,255), 'fps '+str(round(clock.get_fps(),4)), centered = False))
        labels.append(Label(Vec2(10, height-32), 11, (255,255,255), 'res '+str(width)+'x'+str(height), centered = False))
        labels.append(Label(Vec2(10, height-44), 11, (255,255,255), 'sce '+scene, centered = False))
        if clicking:
            labels.append(Label(Vec2(10, height-56), 11, (255,255,255), 'clk True', centered = False))
        else:
            labels.append(Label(Vec2(10, height-56), 11, (255,255,255), 'clk False', centered = False))
        for button in buttons:
            pygame.draw.rect(screen, (75,0,0), pygame.Rect(button.position.x, button.position.y, button.dimension.x, button.dimension.y), 1)
        for label in labels:
            pygame.draw.rect(screen, (0,0,75), pygame.Rect(0, label.position.y, width, 1))

    # ui drawing
    for button in buttons:
        if len(button.text) > 2:
            if button.is_hovered(Vec2(mouse_x, mouse_y)):
                button.draw(screen, size=20, image=BUTTON_WIDE_HOVERED)
            else:
                button.draw(screen, size=20, image=BUTTON_WIDE)
        else:
            if button.is_hovered(Vec2(mouse_x, mouse_y)):
                button.draw(screen, size=20, image=BUTTON_SMALL_HOVERED)
            else:
                button.draw(screen, size=20, image=BUTTON_SMALL)
    for label in labels:
            label.draw(screen)

    # update
    pygame.display.update()
    clock.tick(options['fps'])
'''
