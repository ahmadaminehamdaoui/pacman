import pygame, ctypes, sys, functools
from classes import *
from lang.lang import *
user32 = ctypes.windll.user32
width, height = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)

scene = 'menu'
options = {
    "volume": 60,
    "fps": 60,
    "lang": 'fr',
    "dev": False
}
paint_id = 0

def stop():
    pygame.quit()
    sys.exit()

def set_scene(value):
    global scene
    scene = value

def set_option(option, value):
    global options

    if option == "volume":
        options[option] = value
        if options[option] < 0: options[option]=0
        elif options[option] > 100: options[option]=100
    elif option == "fps":
        if value > 0:
            if options[option] == 15: options[option] = 30
            else: options[option] = 60
        else:
            if options[option] == 60: options[option] = 30
            else: options[option] = 15
    else: options[option] = value

def set_paint_id(value):
    global paint_id
    paint_id = value

def get_option(option):
    return str(options[option])

scenes = {
    'menu': {
        'buttons': [Button(Vec2(width/2-125,height*0.55),Vec2(250,60),(255,255,255),lambda:set_scene('pregame'),text='&txt_play'),
                    Button(Vec2(width/2-125,height*0.55+55),Vec2(250,60),(255,255,255),lambda:set_scene('preeditor'),text='&txt_editor'),
                    Button(Vec2(width/2-125,height*0.55+110),Vec2(250,60),(255,255,255),lambda:set_scene('settings'),text='&txt_settings'),
                    Button(Vec2(width/2-125,height*0.55+165),Vec2(250,60),(255,255,255),lambda:stop(),text='&txt_quit')], 
        'labels': [Label(Vec2(width/2,height*0.4), 80, (255,216,0), 'PACMAN'),
                   Label(Vec2(width/2,height*0.4+70), 18, (255,0,0), '&txt_subtitle')]
            },

    'settings': {
        'buttons': [Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'),
                    Button(Vec2(width/2-150,height*0.33),Vec2(60,60),(255,255,255),lambda:set_option('volume', options['volume']-5),text='-'),
                    Button(Vec2(width/2+100,height*0.33),Vec2(60,60),(255,255,255),lambda:set_option('volume', options['volume']+5),text='+'),
                    Button(Vec2(width/2-150,height*0.43),Vec2(60,60),(255,255,255),lambda:set_option('fps', -1),text='-'),
                    Button(Vec2(width/2+100,height*0.43),Vec2(60,60),(255,255,255),lambda:set_option('fps', +1),text='+'),
                    Button(Vec2(width/2-150,height*0.53),Vec2(60,60),(255,255,255),lambda:set_option('lang', 'fr'),text='f'),
                    Button(Vec2(width/2+100,height*0.53),Vec2(60,60),(255,255,255),lambda:set_option('lang', 'en'),text='e'),
                    Button(Vec2(width/2-150,height*0.63),Vec2(60,60),(255,255,255),lambda:set_option('dev', False),text='x'),
                    Button(Vec2(width/2+100,height*0.63),Vec2(60,60),(255,255,255),lambda:set_option('dev', True),text='o')], 
        'labels': [Label(Vec2(width/2,height*0.35), 20, (255,255,255), '&txt_volume'),
                   Label(Vec2(width/2,height*0.35+30), 15, (255,255,255), '#volume'),
                   Label(Vec2(width/2,height*0.45), 20, (255,255,255), '&txt_fps'),
                   Label(Vec2(width/2,height*0.45+30), 15, (255,255,255), '#fps'),
                   Label(Vec2(width/2,height*0.55), 20, (255,255,255), '&txt_language'), #translate(get_option('lang'), 'txt_language')),
                   Label(Vec2(width/2,height*0.55+30), 15, (255,255,255), '#lang'),
                   Label(Vec2(width/2,height*0.65), 20, (255,255,255), '&txt_dev'),
                   Label(Vec2(width/2,height*0.65+30), 15, (255,255,255), '#dev')]
                },
    
    'preeditor': {
        'buttons': [Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'),
        Button(Vec2(width/2-125,height-110),Vec2(250,60),(255,255,255),lambda:set_scene('newmap'),text='&txt_newmap'),
                    Button(Vec2(width/2-125,height-60),Vec2(250,60),(255,255,255),lambda:set_scene('editor'),text='&txt_confirm')], 
        'labels': []
              },
    
    'newmap': {
        'buttons': [], 
        'labels': []
              },

    'editor': {
        'buttons': [Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'),
                    Button(Vec2(15,55*1+15),Vec2(200,60),(255,255,255),lambda:set_paint_id(0),text='&txt_eraser'),
                    Button(Vec2(15,55*2+15),Vec2(200,60),(255,255,255),lambda:set_paint_id(1),text='&txt_tile'),
                    Button(Vec2(15,55*3+35),Vec2(200,60),(255,255,255),lambda:set_paint_id(2),text='blinky'),
                    Button(Vec2(15,55*4+35),Vec2(200,60),(255,255,255),lambda:set_paint_id(3),text='pinky'),
                    Button(Vec2(15,55*5+35),Vec2(200,60),(255,255,255),lambda:set_paint_id(4),text='inky'),
                    Button(Vec2(15,55*6+35),Vec2(200,60),(255,255,255),lambda:set_paint_id(5),text='clyde'),
                    Button(Vec2(15,55*7+35),Vec2(200,60),(255,255,255),lambda:set_paint_id(6),text='pacman'),
                    Button(Vec2(15,55*8+55),Vec2(200,60),(255,255,255),lambda:set_paint_id(7),text='&txt_power_pellet')], 
        'labels': []
              },
    
    'pregame': {
        'buttons': [Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<'),
                    Button(Vec2(width/2-125,height-60),Vec2(250,60),(255,255,255),lambda:set_scene('ingame_classic'),text='&txt_confirm')], 
        'labels': []
              },

    'ingame_classic': {
        'buttons': [Button(Vec2(15,15),Vec2(60,60),(255,255,255),lambda:set_scene('menu'),text='<')], 
        'labels': []
              },
    
    
}