# TO DO
#

# modules
import pygame, os, ctypes, json
from pygame.constants import K_BACKSPACE, K_F1, K_F2, K_F3, K_F4, K_F5, K_F6, K_F7, K_F8, K_F9
from pygame.display import update
from math import sqrt
from random import randint
from tkinter.messagebox import *

# .py files
import scenes
from classes import *
from lang.lang import *

# get screen resolution
user32 = ctypes.windll.user32
width, height = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
scenes.load_options()


# setup
pygame.init()
pygame.display.init()
screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
clock = pygame.time.Clock()
pygame.display.set_caption('Pacman 2022')

# images
images = {
    'BUTTON_SMALL': pygame.image.load('content/sprites/UI/button_small.png'),
    'BUTTON_SMALL_HOVERED': pygame.transform.scale(pygame.image.load('content/sprites/UI/button_small.png'),(int(pygame.image.load('content/sprites/UI/button_small.png').get_width()*1.2), int(pygame.image.load('content/sprites/UI/button_small.png').get_height()*1.2))),
    'BUTTON_WIDE': pygame.image.load('content/sprites/UI/button_wide.png'),
    'BUTTON_WIDE_HOVERED': pygame.transform.scale(pygame.image.load('content/sprites/UI/button_wide.png'),(int(pygame.image.load('content/sprites/UI/button_wide.png').get_width()*1.2), int(pygame.image.load('content/sprites/UI/button_wide.png').get_height()*1.2))),
    'BUTTON_ULTRAWIDE': pygame.image.load('content/sprites/UI/button_ultrawide.png'),
    'BUTTON_ULTRAWIDE_HOVERED': pygame.transform.scale(pygame.image.load('content/sprites/UI/button_ultrawide.png'),(int(pygame.image.load('content/sprites/UI/button_ultrawide.png').get_width()*1.2), int(pygame.image.load('content/sprites/UI/button_ultrawide.png').get_height()*1.2))),
    'BUTTON_GIGANTIC': pygame.image.load('content/sprites/UI/button_gigantic.png'),
    'BUTTON_GIGANTIC_HOVERED': pygame.transform.scale(pygame.image.load('content/sprites/UI/button_gigantic.png'),(int(pygame.image.load('content/sprites/UI/button_gigantic.png').get_width()*1.2), int(pygame.image.load('content/sprites/UI/button_gigantic.png').get_height()*1.2))),
}

# variables
clicking = False
tilesheet = []
maps = []
dynamic_labels = []
effects = []
buttons = []
entry = None
loaded_file = ''
loaded_highscore = 0

player = None
player_move_per_frame = 0
ghosts = []
isVictory = False
isDefeat = False

main_state_timer = 0
main_state = 'scatter'
frames = 0
draw_frame = 0

main_ghostFrame_timer = 0
main_ghostFrame = '0'
main_frightened_tick = 0
main_frightened_timer = 0
main_pacmanFrame_timer = 0
main_pacmanFrame = '0'
main_pacmanInvincibility = 0

display_fps = False
old_fps = []

def get_tile_sprite(tilesheet, y, x):
    temp = []
    if x-1>=0:
        if tilesheet[y][x-1] == 1:
            temp.append('LEFT')
    if y-1>=0:
        if tilesheet[y-1][x] == 1:
            temp.append('UP')
    if x+1<len(tilesheet[0]):
        if tilesheet[y][x+1] == 1:
            temp.append('RIGHT')
    if y+1<len(tilesheet):
        if tilesheet[y+1][x] == 1:
            temp.append('DOWN')

    result = ''
    for i in range(len(temp)):
        result += temp[i]
        if i < len(temp)-1:
            result += '_'
    if result == '': result = 'NONE'

    try: return pygame.image.load('content/sprites/tiles/'+result+'.png')
    except:
        return pygame.image.load('content/sprites/tiles/ERROR.png')

tile_size = 30
tilesheet = []
tiles = []
objects = []

for y in range(len(tilesheet)):
    for x in range(len(tilesheet[0])):
        if tilesheet[y][x]==1:
            tiles.append([[x*tile_size,y*tile_size], get_tile_sprite(tilesheet, y, x)])
        elif tilesheet[y][x]==0:
            objects.append(Pellet([x*tile_size, y*tile_size], 'classic'))

# functions
def isColliding(rect1, rect2, width1, width2):
    width1 -= 1
    width2 -= 1
    if rect1[0] < rect2[0]+width1 and rect1[0]+width2 > rect2[0] and rect1[1] < rect2[1] + width1 and width1 + rect1[1] > rect2[1]:
        return True
    return False

def dist(pos1, pos2):
    return sqrt((pos2[0]-pos1[0])**2+(pos2[1]-pos1[1])**2)

def load_map(tilesheet):
    global loaded_file
    tiles = []
    objects = []
    for y in range(len(tilesheet)):
        for x in range(len(tilesheet[0])):
            if tilesheet[y][x]==0: # empty, add a pellet
                if loaded_file == 'original.json':
                    if not(x==9 and y==8):
                        objects.append(Pellet([x*tile_size+tile_size/2-2, y*tile_size+tile_size/2-2], 'classic'))
                else:
                    objects.append(Pellet([x*tile_size+tile_size/2-2, y*tile_size+tile_size/2-2], 'classic'))
            if tilesheet[y][x]==1: # solid tile, add collision
                tiles.append([[x*tile_size,y*tile_size], get_tile_sprite(tilesheet, y, x)])
            elif tilesheet[y][x]==7: # add a power pellet
                objects.append(Pellet([x*tile_size+tile_size/2-5, y*tile_size+tile_size/2-5], 'power'))
    if loaded_file == 'original.json':
        tiles.append([[9*tile_size,8*tile_size], pygame.image.load('content/sprites/tiles/SPECIAL.png')])
    return tiles, objects

def score(new_score):
    if new_score > 50:
        color_ = (0,255,255)
    else:
        color_ = (255,255,255)
    dynamic_labels.append(DynamicLabel(Vec2(origin[0], origin[1]-55), Vec2(0, -2), 15, color_, '+'+str(new_score), centered=False))

def reset():
    global player, isVictory, isDefeat
    isVictory = False
    isDefeat = False
    player = None

# ------- tk ------- #
'''def open_file():
    window = Tk()
    window.withdraw()
    filepath = filedialog.askopenfilename(initialdir='pacman/content/data', filetypes=[('Json File','.json'), ('All files','.*')])
    if filepath:
        try:
            data = json.loads(open(str(filepath), 'r', encoding='utf-8').read())
            tilesheet_ = data['tilesheet']
        except:
                pass
        return tilesheet_'''

def update_files():
    files = os.listdir('./content/data')
    for file in files:
        if not '.json' in file:
            files.remove(file)
    return files
maps = list(update_files())

def save_and_set_scene(file_name, scene):
    global maps
    content = {
                "tilesheet": [[0,0,0],[0,0,0],[0,0,0]],
                "highscore": 0
              }
    file = open(os.getcwd()+'/content/data/'+file_name, 'w')
    file.write(str(content).replace("'", '"'))
    file.close()
    scenes.set_scene(scene)
    maps = list(update_files())

def save_file(file_name, tilesheet):
    global dynamic_labels

    count = 0
    for y in range(len(tilesheet)):
        for x in range(len(tilesheet[0])):
            if tilesheet[y][x] == 6: count += 1
    if count>0:
        count = 0
        content = {
                    "tilesheet": tilesheet,
                    "highscore": 0
                }
        file = open(os.getcwd()+'/content/data/'+file_name, 'w')
        file.write(str(content).replace("'", '"'))
        file.close()
        dynamic_labels.append(DynamicLabel(Vec2(430, 35), Vec2(0, 0), 15, (255,255,255), '&txt_saved', centered=False))
    else:
        dynamic_labels.append(DynamicLabel(Vec2(430, 35), Vec2(0, 0), 15, (255,0,0), '&txt_notsaved', centered=False, fade_speed=0.2))

def save_highscore(file_name, highscore, tilesheet):
    content = {
                    "tilesheet": tilesheet,
                    "highscore": highscore
              }
    file = open(os.getcwd()+'/content/data/'+file_name, 'w')
    file.write(str(content).replace("'", '"'))
    file.close()

###
def set_tilesheet(file):
    global tilesheet
    data = json.loads(open(str(os.getcwd()+'/content/data/'+file), 'r', encoding='utf-8').read())
    tilesheet = data['tilesheet']

def set_highscore(file):
    global loaded_highscore
    data = json.loads(open(str(os.getcwd()+'/content/data/'+file), 'r', encoding='utf-8').read())
    loaded_highscore = data['highscore']

def set_tilesheet_and_name(file):
    global loaded_file, loaded_highscore
    set_tilesheet(file)
    loaded_file = file
    set_highscore(file)

'''def partial(file):
        return lambda:set_tilesheet(file)'''

def second_partial(file_name, scene):
    return lambda:save_and_set_scene(file_name, scene)

def third_partial(file):
    return lambda:set_tilesheet_and_name(file)

def modify_tilesheet(mode, value):
    global tilesheet
    if mode == 'x':
        if value < 0:
            for line in tilesheet:
                line.pop(len(line)-1)
        else:
            for line in tilesheet:
                line.append(0)
    else:
        if value < 0:
            tilesheet.pop(len(tilesheet)-1)
        else:
            tilesheet.append([0 for i in range(len(tilesheet[0]))])

# main game logic
frame_recalc = 0
while True:
    # loop init
    screen.fill((0,0,0))
    mouse_x, mouse_y = pygame.mouse.get_pos()

    current_fps = round(clock.get_fps(),4)

    # scenes
    buttons = list(scenes.scenes[scenes.scene]['buttons'])
    labels = list(scenes.scenes[scenes.scene]['labels'])

    # -------------------------------------------------------------- #
    # -------------------------------------------------------------- #
    if scenes.scene == 'menu':
        tilesheet = []

    elif scenes.scene == 'pregame' or scenes.scene == 'preeditor':
        labels.append(Label(Vec2(width/2,height/2-(len(maps)*30)-60), 20, (255,255,255), '&txt_select'))
        labels.append(Label(Vec2(width/2,height/2-(len(maps)*30)-25), 15, (255,255,255), loaded_file))
        for i in range(len(maps)):
            buttons.append(Button(Vec2(width/2-125,height*0.55+i*60-(len(maps)*30)),Vec2(250,60),(255,255,255),third_partial(maps[i]),text=maps[i].replace('.json', '')))

    elif scenes.scene == 'ingame_classic':
        dimensions = (len(tilesheet[0]), len(tilesheet))
        origin = (int((width/2)-(dimensions[0]*tile_size/2)), int((height/2)-(dimensions[1]*tile_size/2)))

        # on enter
        if player == None:
            frames = 0
            ghosts = []
            for y in range(len(tilesheet)):
                for x in range(len(tilesheet[0])):
                    if tilesheet[y][x] == 2:
                        ghosts.append(Ghost('blinky', [x*tile_size,y*tile_size]))
                    elif tilesheet[y][x] == 3:
                        ghosts.append(Ghost('pinky', [x*tile_size,y*tile_size]))
                        if loaded_file == 'original.json':
                            ghosts.append(Ghost('blinky', [x*tile_size,y*tile_size]))
                    elif tilesheet[y][x] == 4:
                        ghosts.append(Ghost('inky', [x*tile_size,y*tile_size]))
                    elif tilesheet[y][x] == 5:
                        ghosts.append(Ghost('clyde', [x*tile_size,y*tile_size]))
                    elif tilesheet[y][x] == 6:
                        player = Player((x*tile_size, y*tile_size), 'right')
            tiles, objects = load_map(tilesheet)

        # main loop
        if not isVictory and not isDefeat :

            # specific drawing
            if loaded_file == 'original.json':
                pygame.draw.rect(screen, (253,182,220), pygame.Rect(origin[0]+9*tile_size, origin[1]+8*tile_size+tile_size/2-1, tile_size, 2))
            #################
            # player_move_per_frame = int(12/(clock.get_fps()/15))
            player_move_per_frame = 12 if scenes.options['fps']==15 else 6 if scenes.options['fps']==30 else 3

            for i in range(player_move_per_frame):
                # velocity
                if player.velocity == 'up':
                    player.position = (player.position[0], player.position[1]-1)
                elif player.velocity == 'down':
                    player.position = (player.position[0], player.position[1]+1)
                elif player.velocity == 'right':
                    player.position = (player.position[0]+1, player.position[1])
                elif player.velocity == 'left':
                    player.position = (player.position[0]-1, player.position[1])

            # collisions
            for i in range(len(tiles)):
                tile = tiles[i][0]
                if isColliding(player.position, tile, player.width, tile_size):
                    player.collision = tile
            while player.collision != None:
                if player.velocity == 'up':
                    player.position = (player.position[0], player.position[1]+1)
                elif player.velocity == 'down':
                    player.position = (player.position[0], player.position[1]-1)
                elif player.velocity == 'right':
                    player.position = (player.position[0]-1, player.position[1])
                elif player.velocity == 'left':
                        player.position = (player.position[0]+1, player.position[1])
                if not isColliding(player.position, player.collision, player.width, tile_size):
                    player.collision = None

            # pellets
            i = 0
            while i < len(objects):
                pellet = objects[i]
                #if isColliding(player.position, pellet.position, player.width, pellet.width):
                if pellet.position[0] > player.position[0] and pellet.position[0] < player.position[0]+player.width and pellet.position[1] > player.position[1] and pellet.position[1] < player.position[1]+player.width:
                    if pellet.pellet_type == 'classic':
                        player.score += 10
                        score(10)
                    elif pellet.pellet_type == 'power':
                        effects.append(Shockwave(tuple((pellet.position[0]+pellet.width/2,pellet.position[1]+pellet.width/2)), 5, 22, 150, 1))
                        player.score += 50
                        score(50)
                        for ghost in ghosts:
                            if ghost.state != 'dead':
                                ghost.state = 'frightened'
                                if ghost.direction == 'right': ghost.direction = 'left'
                                elif ghost.direction == 'left': ghost.direction = 'right'
                                elif ghost.direction == 'up': ghost.direction = 'down'
                                elif ghost.direction == 'down': ghost.direction = 'up'
                            main_frightened_timer = 9
                    objects.remove(pellet)

                    if len(objects) < 1:
                        effects.append(Shockwave(tuple((pellet.position[0]+pellet.width/2,pellet.position[1]+pellet.width/2)), 5, 180, 1200, 4))
                        isVictory = True
                else: i += 1

            # ghosts (frightened and normal)
            for ghost in ghosts:
                if ghost.state == 'frightened' and isColliding(player.position, ghost.position, player.width, ghost.width):
                    effects.append(Shockwave(tuple((ghost.position[0]+ghost.width/2,ghost.position[1]+ghost.width/2)), 5, 15, 100, 1))
                    player.score += ghost.value
                    score(ghost.value)
                    ghost.state = 'dead'
                    ghost.value = 200
                    for ghost_ in ghosts:
                        if ghost_.state == 'frightened':
                            if ghost_.value <= 800:
                                ghost_.value *= 2
                elif ghost.state != 'dead' and  player.invincibility <= 0 and isColliding(player.position, ghost.position, player.width, ghost.width) and not scenes.options['dev']:
                    player.lives -= 1
                    effects.append(Shockwave(tuple((player.position[0]+player.width/2,player.position[1]+player.width/2)), 5, 90, 600, 2))
                    if player.lives > 0:
                        player.position = player.spawnpoint
                        player.invincibility = 4
                    else:
                        isDefeat = True

            for i in range(player_move_per_frame):
                # future velocity
                futureIsColliding = False
                for i in range(len(tiles)):
                    tile = tiles[i][0]
                    if player.try_velocity == 'up':
                        if isColliding((player.position[0], player.position[1]-5), tile, player.width, tile_size):
                            futureIsColliding = True
                    elif player.try_velocity == 'down':
                        if isColliding((player.position[0], player.position[1]+5), tile, player.width, tile_size):
                            futureIsColliding = True
                    elif player.try_velocity == 'right':
                        if isColliding((player.position[0]+5, player.position[1]), tile, player.width, tile_size):
                            futureIsColliding = True
                    elif player.try_velocity == 'left':
                        if isColliding((player.position[0]-5, player.position[1]), tile, player.width, tile_size):
                            futureIsColliding = True
                if not futureIsColliding and player.try_velocity != None:
                    player.velocity = player.try_velocity
                    player.try_velocity = None

            # boundaries
            if player.position[0]+player.width > dimensions[0]*tile_size:
                player.position = (0, player.position[1])
            elif player.position[0] < 0:
                player.position = (dimensions[0]*tile_size-player.width, player.position[1])
            elif player.position[1]+player.width > dimensions[1]*tile_size:
                player.position = (player.position[0], 0)
            elif player.position[1] < 0:
                player.position = (player.position[0], dimensions[1]*tile_size-player.width)

            # lives
            for i in range(player.lives):
                screen.blit(player.sprites['1'], (origin[0]+i*40, origin[1]+dimensions[1]*tile_size+10))

            # timers
            frames += 1
            main_ghostFrame_timer += 1
            main_pacmanFrame_timer += 1
            if main_frightened_timer > 0:
                main_frightened_tick += 1
            if player.invincibility > 0:
                main_pacmanInvincibility += 1

            if frames >= round(current_fps, 0): # counting frames for scattering/chase mode
                main_state_timer += 1
                frames = 0
            if main_state == 'scatter' and main_state_timer >= 5:
                for ghost in ghosts:
                    if ghost.state=='scatter' or ghost.state =='chase':
                        if ghost.direction == 'right': ghost.direction = 'left'
                        elif ghost.direction == 'left': ghost.direction = 'right'
                        elif ghost.direction == 'up': ghost.direction = 'down'
                        elif ghost.direction == 'down': ghost.direction = 'up'
                main_state = 'chase'
                main_state_timer = 0
            elif main_state == 'chase' and main_state_timer >= 20:
                for ghost in ghosts:
                    if ghost.state=='scatter' or ghost.state =='chase':
                        if ghost.direction == 'right': ghost.direction = 'left'
                        elif ghost.direction == 'left': ghost.direction = 'right'
                        elif ghost.direction == 'up': ghost.direction = 'down'
                        elif ghost.direction == 'down': ghost.direction = 'up'
                main_state = 'scatter'
                main_state_timer = 0

            if player.invincibility > 0 and main_pacmanInvincibility >= round(current_fps, 0): # counting iframes for pacman
                player.invincibility -= 1
                main_pacmanInvincibility = 0

            if main_frightened_tick >= round(current_fps, 0): # counting frames for frightened mode
                main_frightened_timer -= 1
                main_frightened_tick = 0
                if main_frightened_timer <= 0:
                    for ghost in ghosts:
                        ghost.value = 200
                        if ghost.state == 'frightened':
                            ghost.state = main_state

            if main_ghostFrame_timer >= round(current_fps, 0)/6: # ghost sprite frames
                main_ghostFrame = '1' if main_ghostFrame=='0' else '0'
                main_ghostFrame_timer = 0

            if main_pacmanFrame_timer >= round(current_fps, 0)/30: # pacman sprite frames
                main_pacmanFrame = '0' if main_pacmanFrame=='3' else '1' if main_pacmanFrame=='0' else '2' if main_pacmanFrame=='1' else '3'
                main_pacmanFrame_timer = 0

            if player.invincibility <= 0:
                player.sprite = player.sprites[main_pacmanFrame]
            else:
                 player.sprite = player.sprites['alpha'+main_pacmanFrame]

            if scenes.options['dev']:
                labels.append(Label(Vec2(origin[0], origin[1]+dimensions[1]*tile_size+10), 15, (255,255,255), main_state+' '+str(main_state_timer), centered=False))
                labels.append(Label(Vec2(origin[0], origin[1]+dimensions[1]*tile_size+30), 15, (255,255,255), 'frightened '+str(main_frightened_timer), centered=False))

        # ghosts ------------------------------------------------------------

            for ghost in ghosts:
                if ghost.state == 'scatter' or ghost.state == 'chase':
                    ghost.state = main_state
                    ghost.sprite = ghost.sprites[ghost.direction+main_ghostFrame]
                elif ghost.state == 'frightened':
                    ghost.sprite = ghost.sprites['frightened'+main_ghostFrame]
                else:
                    ghost.sprite = ghost.sprites['dead'+ghost.direction]

                # target
                if ghost.name == 'blinky':
                    if ghost.state == 'chase':
                        ghost.target = player.position
                    elif ghost.state == 'scatter':
                        ghost.target = ((dimensions[0]-1)*tile_size, -tile_size*2)
                elif ghost.name == 'pinky':
                    if ghost.state == 'chase':
                        if player.velocity == 'up': ghost.target = (player.position[0]-3*tile_size, player.position[1]-3*tile_size)
                        elif player.velocity == 'right': ghost.target = (player.position[0]+3*tile_size, player.position[1])
                        elif player.velocity == 'down': ghost.target = (player.position[0], player.position[1]+3*tile_size)
                        elif player.velocity == 'left': ghost.target = (player.position[0]-3*tile_size, player.position[1])
                    elif ghost.state == 'scatter':
                        ghost.target = (tile_size, -tile_size*2)
                elif ghost.name == 'inky':
                    if ghost.state == 'chase':
                        if player.velocity == 'up': ghost.target = (player.position[0]-1.5*tile_size, player.position[1]-1.5*tile_size)
                        elif player.velocity == 'right': ghost.target = (player.position[0]+1.5*tile_size, player.position[1])
                        elif player.velocity == 'down': ghost.target = (player.position[0], player.position[1]+1.5*tile_size)
                        elif player.velocity == 'left': ghost.target = (player.position[0]-1.5*tile_size, player.position[1])
                        for ghost_ in ghosts:
                            if ghost_.name == 'blinky':
                                objective = ghost_
                        rotation_vector = (ghost.target[0]-objective.position[0],ghost.target[1]-objective.position[1])
                        ghost.target = (ghost.target[0]+rotation_vector[0], ghost.target[1]+rotation_vector[1])
                    elif ghost.state == 'scatter':
                        ghost.target = (dimensions[0]*tile_size, dimensions[1]*tile_size)
                elif ghost.name == 'clyde':
                    if ghost.state == 'chase':
                        if dist(ghost.position, player.position) > tile_size*4:
                            ghost.target = player.position
                        else:
                            ghost.target = [0, len(tilesheet)*tile_size]
                    elif ghost.state == 'scatter':
                        ghost.target = (0, dimensions[1]*tile_size)

                if scenes.options['dev'] and ghost.state != 'frightened':
                    color = (255,0,0) if ghost.name == 'blinky' else (255,147,53) if ghost.name == 'clyde' else (0,255,255) if ghost.name == 'inky' else (255,150,251)
                    labels.append(Label(Vec2(ghost.target[0]+origin[0], ghost.target[1]+origin[1]), 8, color, 'x'))
                    pygame.draw.circle(screen, (255,147,53), (player.position[0]+origin[0], player.position[1]+origin[1]), 4*tile_size, 1)

                mult = 0.5 if ghost.state == 'frightened' else 2 if ghost.state == 'dead' else 1
                ghost_move_per_frame = 8*mult if scenes.options['fps']==15 else 4*mult if scenes.options['fps']==30 else 2*mult
                for i in range(int(ghost_move_per_frame)):
                    if ghost.state == 'dead':
                        ghost.target = ghost.spawnpoint
                        if (ghost.position[0]//tile_size, ghost.position[1]//tile_size) == (ghost.spawnpoint[0]//tile_size, ghost.spawnpoint[1]//tile_size):
                            ghost.state = main_state

                    # check every possible move
                    if ghost.position[0]%tile_size==0 and ghost.position[1]%tile_size==0: # then ghost is on a plain tile
                        moves = ['up', 'left', 'down', 'right']
                        try:
                            if tilesheet[ghost.position[1]//tile_size-1][ghost.position[0]//tile_size] == 1 or ghost.direction == 'down':
                                moves.remove('up')
                        except: moves.remove('up')
                        try:
                            if tilesheet[ghost.position[1]//tile_size][ghost.position[0]//tile_size-1] == 1 or ghost.direction == 'right':
                                moves.remove('left')
                        except: moves.remove('left')
                        try:
                            if tilesheet[ghost.position[1]//tile_size+1][ghost.position[0]//tile_size] == 1 or ghost.direction == 'up':
                                moves.remove('down')
                        except: moves.remove('down')
                        try:
                            if tilesheet[ghost.position[1]//tile_size][ghost.position[0]//tile_size+1] == 1  or ghost.direction == 'left':
                                moves.remove('right')
                        except: moves.remove('right')

                        # what is the nearest tile to the target ?
                        if ghost.state == 'frightened':
                            if len(moves)>0:
                                choice = randint(0, len(moves)-1)
                                ghost.direction = moves[choice]
                            else:
                                if  ghost.direction == 'right': ghost.direction = 'left'
                                elif  ghost.direction == 'left': ghost.direction = 'right'
                                elif  ghost.direction == 'up': ghost.direction = 'down'
                                elif  ghost.direction == 'down': ghost.direction = 'up'
                        else:
                            distances = []
                            for move in moves:
                                if move == 'right':
                                    distances.append([round(dist((ghost.position[0]+tile_size, ghost.position[1]), ghost.target),3), 'right'])
                                elif move == 'down':
                                    distances.append([round(dist((ghost.position[0], ghost.position[1]+tile_size), ghost.target),3), 'down'])
                                elif move == 'left':
                                    distances.append([round(dist((ghost.position[0]-tile_size, ghost.position[1]), ghost.target),3), 'left'])
                                elif move == 'up':
                                    distances.append([round(dist((ghost.position[0], ghost.position[1]-tile_size), ghost.target),3), 'up'])

                            if distances == []:
                                if  ghost.direction == 'right': distances.append([0,'left'])
                                elif  ghost.direction == 'left': distances.append([0,'right'])
                                elif  ghost.direction == 'up': distances.append([0,'down'])
                                elif  ghost.direction == 'down': distances.append([0,'up'])

                            smaller = distances[0]
                            for i in range(len(distances)):
                                if distances[i][0] < smaller[0]: smaller = distances[i]
                            ghost.direction = smaller[1]

                    # boundaries
                    if ghost.position[0] > (dimensions[0]-1)*tile_size-2:
                        ghost.position[0] = 0
                    elif ghost.position[0] < 0:
                        ghost.position[0] = (dimensions[0]-1)*tile_size-3
                    elif ghost.position[1] > (dimensions[1]-1)*tile_size-2  :
                        ghost.position[1] = 0
                    elif ghost.position[1] < 0:
                        ghost.position[1] = (dimensions[1]-1)*tile_size-3

                    # basic movement
                    if ghost.direction == 'up': ghost.position[1] -= 1
                    elif ghost.direction == 'left': ghost.position[0] -= 1
                    elif ghost.direction == 'down': ghost.position[1] += 1
                    elif ghost.direction == 'right': ghost.position[0] += 1

                if scenes.options['dev'] :
                    labels.append(Label(Vec2(origin[0]+ghost.position[0]+ghost.width/2, origin[1]+ghost.position[1]-5), 10, (255,255,255), str((ghost.position[0]//tile_size, ghost.position[1]//tile_size)), centered=True))
                    labels.append(Label(Vec2(origin[0]+ghost.position[0]+ghost.width/2, origin[1]+ghost.position[1]+35), 10, (255,255,255), str(ghost.value), centered=True))

            # map drawing
            for i in range(len(tiles)):
                screen.blit(tiles[i][1], (tiles[i][0][0]+origin[0], tiles[i][0][1]+origin[1]))
            for i in range(len(objects)):
                screen.blit(objects[i].sprite, (objects[i].position[0]+origin[0],objects[i].position[1]+origin[1]))

            # player drawing
            if player.velocity == 'up': player.rotation = 90
            elif player.velocity == 'down': player.rotation = 270
            elif player.velocity == 'right': player.rotation = 0
            elif player.velocity == 'left': player.rotation = 180

            if scenes.options['dev']:
                pygame.draw.rect(screen, (255,0,0), pygame.Rect(origin[0]+player.position[0], origin[1]+player.position[1], player.width-1, player.width-1), 1)
            final_sprite = pygame.transform.rotate(player.sprite, player.rotation)
            screen.blit(final_sprite, (origin[0]+player.position[0], origin[1]+player.position[1]))

            # ghosts drawing
            for ghost in ghosts:
                screen.blit(ghost.sprite, (origin[0]+ghost.position[0], origin[1]+ghost.position[1]))

            # UI drawing
            labels.append(Label(Vec2(origin[0], origin[1]-35), 15, (255,255,255), 'score: '+str(player.score), centered=False))

        elif isVictory:
            # victory screen
            if loaded_highscore < player.score:
                loaded_highscore = player.score
                save_highscore(loaded_file, loaded_highscore, tilesheet)
            labels.append(Label(Vec2(width/2, height/2-80), 20, (255,255,0), '&txt_victory', centered=True))
            labels.append(Label(Vec2(width/2-6*15, height/2-40), 20, (255,255,255), 'score '+str(player.score), centered=False))
            labels.append(Label(Vec2(width/2-11*15-5, height/2-10), 20, (255,255,255), 'highscore '+str(loaded_highscore), centered=False))
            buttons.append(Button(Vec2(width/2-125, height/2+40), Vec2(250,60), (255,255,255),lambda:scenes.set_scene('pregame'),text='&txt_retry'))

        else:
            # defeat screen
            labels.append(Label(Vec2(width/2, height/2-40), 20, (255,0,0), '&txt_defeat', centered=True))
            buttons.append(Button(Vec2(width/2-125, height/2+10), Vec2(250,60), (255,255,255),lambda:scenes.set_scene('pregame'),text='&txt_retry'))

    # -------------------------------------------------------------- #
    # -------------------------------------------------------------- #

    elif scenes.scene == 'newmap':
        if entry == None:
            entry = Entry((200,200), (140,32))
        labels.append(Label(Vec2(width/2,height/2), 20, (255,255,255), entry.text+'.json'))
        buttons.append(Button(Vec2(width/2-125,height/2+60),Vec2(250,60),(255,255,255),second_partial(entry.text+'.json', 'preeditor'),text='&txt_confirm'))

    elif scenes.scene == 'editor':
        buttons.append(Button(Vec2(width-170, 15),Vec2(60,60),(255,255,255),lambda:modify_tilesheet('x', -1),text='-'))
        buttons.append(Button(Vec2(width-70,15),Vec2(60,60),(255,255,255),lambda:modify_tilesheet('x', 1),text='+'))
        labels.append(Label(Vec2(width-101,30), 20, (255,255,255), 'x', centered=False))

        buttons.append(Button(Vec2(width-170, 75),Vec2(60,60),(255,255,255),lambda:modify_tilesheet('y', -1),text='-'))
        buttons.append(Button(Vec2(width-70,75),Vec2(60,60),(255,255,255),lambda:modify_tilesheet('y', 1),text='+'))
        labels.append(Label(Vec2(width-103,90), 20, (255,255,255), 'y', centered=False))

        # variables
        dimensions = (len(tilesheet[0]), len(tilesheet))
        origin = ((width/2)-(dimensions[0]*tile_size/2), (height/2)-(dimensions[1]*tile_size/2))

        # painting
        if clicking:
            if mouse_x >= origin[0] and mouse_x < origin[0]+dimensions[0]*tile_size and mouse_y >= origin[1] and mouse_y < origin[1]+dimensions[1]*tile_size:
                if 7>scenes.paint_id>1:
                    for y in range(len(tilesheet)):
                        for x in range(len(tilesheet[0])):
                            if tilesheet[y][x] == scenes.paint_id:
                                tilesheet[y][x] = 0
                tilesheet[int((mouse_y-origin[1])//tile_size)][int((mouse_x-origin[0])//tile_size)] = scenes.paint_id

        # map drawing
        for y in range(dimensions[1]):
            for x in range(dimensions[0]):
                if tilesheet[y][x] == 1:
                    pygame.draw.rect(screen, (0,0,255), pygame.Rect(origin[0]+x*tile_size, origin[1]+y*tile_size, tile_size, tile_size))
                elif tilesheet[y][x] == 2:
                    pygame.draw.rect(screen, (255,0,0), pygame.Rect(origin[0]+x*tile_size, origin[1]+y*tile_size, tile_size, tile_size))
                elif tilesheet[y][x] == 3:
                    pygame.draw.rect(screen, (255,150,251), pygame.Rect(origin[0]+x*tile_size, origin[1]+y*tile_size, tile_size, tile_size))
                elif tilesheet[y][x] == 4:
                    pygame.draw.rect(screen, (0,255,255), pygame.Rect(origin[0]+x*tile_size, origin[1]+y*tile_size, tile_size, tile_size))
                elif tilesheet[y][x] == 5:
                    pygame.draw.rect(screen, (255,147,53), pygame.Rect(origin[0]+x*tile_size, origin[1]+y*tile_size, tile_size, tile_size))
                elif tilesheet[y][x] == 6:
                    pygame.draw.rect(screen, (255,255,0), pygame.Rect(origin[0]+x*tile_size, origin[1]+y*tile_size, tile_size, tile_size))
                elif tilesheet[y][x] == 7:
                    pygame.draw.rect(screen, (250,185,176), pygame.Rect(origin[0]+x*tile_size+tile_size/3, origin[1]+y*tile_size+tile_size/3, tile_size/3, tile_size/3))

                if ((mouse_x-origin[0])//tile_size, (mouse_y-origin[1])//tile_size) == (x, y):
                    pygame.draw.rect(screen, (255,255,255), pygame.Rect(origin[0]+x*tile_size, origin[1]+y*tile_size, tile_size, tile_size),1)
                else:
                    pygame.draw.rect(screen, (50,50,50), pygame.Rect(origin[0]+x*tile_size, origin[1]+y*tile_size, tile_size, tile_size),1)
        buttons.append(Button(Vec2(125 if scenes.options['lang']=='fr' else 85,15),Vec2(250,60),(255,255,255),lambda:save_file(loaded_file, tilesheet),text='&txt_save'))

    if scenes.scene != 'ingame_classic':
        player = None
        isVictory = False
        isDefeat = False
        ghosts = []
    elif scenes.scene != 'newmap':
        entry = None

    # events handler
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            scenes.stop()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            clicking = True
            for button in buttons:
                if button.is_hovered(Vec2(mouse_x, mouse_y)):
                    button.action()
        elif event.type == pygame.MOUSEBUTTONUP:
            clicking = False

        elif event.type == pygame.KEYDOWN:
            if event.key == K_F1:
                scenes.set_option('volume', scenes.options['volume']-5)
            elif event.key == K_F2:
                scenes.set_option('volume', scenes.options['volume']+5)
            elif event.key == K_F3:
                scenes.set_option('fps', -1)
            elif event.key == K_F4:
                scenes.set_option('fps', +1)
            elif event.key == K_F5:
                scenes.options['lang'] = 'en' if scenes.options['lang']=='fr' else 'fr'
            elif event.key == K_F6:
                scenes.options['dev'] = False if scenes.options['dev'] else True
            elif event.key == K_F7:
                display_fps = False if display_fps else True
            elif event.key == K_F8:
                isDefeat = True
            elif event.key == K_F9:
                isVictory = True

            if entry != None:
                if event.key == K_BACKSPACE:
                    entry.text = entry.text[:-1]
                else:
                    entry.text += event.unicode
                    entry.text = entry.text.replace(' ', '_').strip('\/:*?"<>|')
                    if '\r' in entry.text:
                        entry.text = entry.text.strip('\r')
                        save_and_set_scene(entry.text+'.json', 'preeditor')

            if 'ingame' in scenes.scene:
                if event.key == pygame.K_UP:
                    player.try_velocity = 'up'
                    player.rotation = 90
                elif event.key == pygame.K_DOWN:
                    player.try_velocity = 'down'
                    player.rotation = 270
                elif event.key == pygame.K_RIGHT:
                    player.try_velocity = 'right'
                    player.rotation = 0
                elif event.key == pygame.K_LEFT:
                    player.try_velocity = 'left'
                    player.rotation = 180

    # dev mode
    if display_fps:
        labels.append(Label(Vec2(10, height-20), 11, (255,255,255), 'fps '+str(current_fps), centered = False))
    if scenes.options['dev']:
        labels.append(Label(Vec2(10, height-20), 11, (255,255,255), 'fps '+str(current_fps), centered = False))
        labels.append(Label(Vec2(10, height-32), 11, (255,255,255), 'res '+str(width)+'x'+str(height), centered = False))
        labels.append(Label(Vec2(10, height-44), 11, (255,255,255), 'sce '+scenes.scene, centered = False))
        if clicking:
            labels.append(Label(Vec2(10, height-56), 11, (255,255,255), 'clk True', centered = False))
        else:
            labels.append(Label(Vec2(10, height-56), 11, (255,255,255), 'clk False', centered = False))
        labels.append(Label(Vec2(10, height-68), 11, (255,255,255), 'vel '+str(player.velocity if player!=None else '-'), centered = False))
        labels.append(Label(Vec2(10, height-80), 11, (255,255,255), 'try '+str(player.try_velocity if player!=None else '-'), centered = False))
        labels.append(Label(Vec2(10, height-102), 11, (255,255,255), 'fil '+loaded_file, centered = False))
        labels.append(Label(Vec2(10, height-114), 11, (255,255,255), 'his '+str(loaded_highscore), centered = False))
        for button in buttons:
            pygame.draw.rect(screen, (75,0,0), pygame.Rect(button.position.x, button.position.y, button.dimension.x, button.dimension.y), 1)
        for label in labels:
            pygame.draw.rect(screen, (0,0,75), pygame.Rect(0, label.position.y, width, 1))
        for dynamic_label in dynamic_labels:
            pygame.draw.rect(screen, (0,75,0), pygame.Rect(0, dynamic_label.position.y, width, 1))

    # ui drawing
    for button in buttons:
        new_text = (translate(scenes.options['lang'], button.text.strip('&')) if '&' in button.text else button.text)

        if len(new_text) < 3:
            used_image = 'BUTTON_SMALL'
        elif len(new_text) < 10:
            used_image = 'BUTTON_WIDE'
        elif len(new_text) < 14:
            used_image = 'BUTTON_ULTRAWIDE'
        else: used_image = 'BUTTON_GIGANTIC'

        if button.is_hovered(Vec2(mouse_x, mouse_y)):
            button.draw(screen, size=20, image=images[used_image+'_HOVERED'], text=new_text)
        else:
            button.draw(screen, size=20, image=images[used_image], text=new_text)

    for label in labels:
            if '#' in label.text:
                label.draw(screen, str(scenes.options[label.text.strip('#')]))
            elif '&' in label.text:
                label.draw(screen, translate(scenes.options['lang'], label.text.strip('&')))
            else:
                label.draw(screen, str(label.text))

    for dynamic_label in dynamic_labels:
        dynamic_label.update()
        if '&' in dynamic_label.text:
                dynamic_label.draw(screen, translate(scenes.options['lang'], dynamic_label.text.strip('&')))
        else:
            dynamic_label.draw(screen, dynamic_label.text)
        if dynamic_label.color == (0,0,0): dynamic_labels.remove(dynamic_label)

    for effect in effects:
        effect.update(round(current_fps,0))
        if effect.thickness <= 1:
            effects.remove(effect)
        else:
            pygame.draw.circle(screen, effect.color, (int(effect.position[0])+origin[0], int(effect.position[1])+origin[1]), effect.radius, int(effect.thickness))

    # update
    pygame.display.update()
    clock.tick(scenes.options['fps'])